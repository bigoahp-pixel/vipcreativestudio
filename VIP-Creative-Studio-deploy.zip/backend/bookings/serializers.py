import re
from pathlib import Path

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from PIL import Image, UnidentifiedImageError
import phonenumbers
from phonenumbers import NumberParseException, PhoneNumberFormat
from django.utils import timezone
from rest_framework import serializers

from .models import Booking, GalleryCategory, GalleryPhoto


SERVICES = [
    "Wedding photography", "Birthday photography", "Portraits", "Graduation", "Events", "Fashion",
    "Family photography", "Commercial photography", "Cultural events", "Sports",
    "Real estate", "Photo editing", "Video production",
]


class BookingCreateSerializer(serializers.ModelSerializer):
    website = serializers.CharField(write_only=True, required=False, allow_blank=True)

    class Meta:
        model = Booking
        fields = [
            "full_name", "email", "phone", "service", "appointment_date",
            "appointment_time", "location", "budget", "people_count",
            "requirements", "preferred_contact", "website",
        ]

    def validate_full_name(self, value):
        value = " ".join(value.split())
        if len(value) < 2 or not re.fullmatch(r"[\w\s.'-]+", value, re.UNICODE):
            raise serializers.ValidationError("Enter a valid name.")
        return value

    def validate_phone(self, value):
        phone_input = value.strip()
        if phone_input.startswith("00"):
            phone_input = f"+{phone_input[2:]}"
        try:
            phone_number = phonenumbers.parse(phone_input, None)
        except NumberParseException as error:
            raise serializers.ValidationError(
                "Include the international country code, for example +211 922 865 522."
            ) from error
        if phone_number.extension or not phonenumbers.is_valid_number(phone_number):
            raise serializers.ValidationError("Enter a valid international phone number with its country code.")
        return phonenumbers.format_number(phone_number, PhoneNumberFormat.E164)

    def validate_service(self, value):
        if value not in SERVICES:
            raise serializers.ValidationError("Select a service from the list.")
        return value

    def validate_appointment_date(self, value):
        if value < timezone.localdate():
            raise serializers.ValidationError("Choose today or a future date.")
        return value

    def validate_people_count(self, value):
        if value is not None and not 1 <= value <= 500:
            raise serializers.ValidationError("Enter a number from 1 to 500.")
        return value

    def validate_requirements(self, value):
        if len(value) > 2000:
            raise serializers.ValidationError("Keep additional requirements under 2,000 characters.")
        return value

    def validate(self, attrs):
        if attrs.pop("website", ""):
            raise serializers.ValidationError({"detail": "Unable to process this request."})
        return attrs


class BookingAdminSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = [
            "id", "reference", "full_name", "email", "phone", "service",
            "appointment_date", "appointment_time", "location", "budget",
            "people_count", "requirements", "preferred_contact", "status",
            "internal_notes", "owner_email_status", "client_email_status",
            "whatsapp_status", "status_email_status", "status_whatsapp_status",
            "created_at", "updated_at",
        ]
        read_only_fields = [
            "id", "reference",
            "owner_email_status", "client_email_status", "whatsapp_status",
            "status_email_status", "status_whatsapp_status",
            "created_at", "updated_at",
        ]

    def validate_full_name(self, value):
        value = " ".join(value.split())
        if len(value) < 2 or not re.fullmatch(r"[\w\s.'-]+", value, re.UNICODE):
            raise serializers.ValidationError("Enter a valid name.")
        return value

    def validate_phone(self, value):
        phone_input = value.strip()
        if phone_input.startswith("00"):
            phone_input = f"+{phone_input[2:]}"
        try:
            phone_number = phonenumbers.parse(phone_input, None)
        except NumberParseException as error:
            raise serializers.ValidationError(
                "Include the international country code, for example +211 922 865 522."
            ) from error
        if phone_number.extension or not phonenumbers.is_valid_number(phone_number):
            raise serializers.ValidationError("Enter a valid international phone number with its country code.")
        return phonenumbers.format_number(phone_number, PhoneNumberFormat.E164)

    def validate_service(self, value):
        if value not in SERVICES:
            raise serializers.ValidationError("Select a service from the list.")
        return value

    def validate_appointment_date(self, value):
        if value < timezone.localdate():
            raise serializers.ValidationError("An appointment cannot be moved to a past date.")
        return value

    def validate_people_count(self, value):
        if value is not None and not 1 <= value <= 500:
            raise serializers.ValidationError("Enter a number from 1 to 500.")
        return value

    def validate_requirements(self, value):
        if len(value) > 2000:
            raise serializers.ValidationError("Keep additional requirements under 2,000 characters.")
        return value


class GalleryCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = GalleryCategory
        fields = ["id", "slug", "title", "service"]
        read_only_fields = ["id", "slug"]

    def validate_title(self, value):
        value = " ".join(value.split())
        if not value:
            raise serializers.ValidationError("Enter a category name.")
        return value

    def validate_service(self, value):
        if value and value not in SERVICES:
            raise serializers.ValidationError("Choose a supported booking service.")
        return value


class GalleryCategoryCreateSerializer(GalleryCategorySerializer):
    slug = serializers.SlugField(max_length=64, required=False)

    def validate(self, attrs):
        if not attrs.get("slug"):
            from django.utils.text import slugify

            attrs["slug"] = slugify(attrs["title"])[:64]
        if not attrs["slug"]:
            raise serializers.ValidationError({"title": "The category needs a valid name."})
        return attrs


class GalleryPhotoSerializer(serializers.ModelSerializer):
    category = serializers.SlugRelatedField(read_only=True, slug_field="slug")
    category_title = serializers.CharField(source="category.title", read_only=True)
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = GalleryPhoto
        fields = ["id", "category", "category_title", "title", "image_url", "created_at"]

    def get_image_url(self, photo):
        request = self.context.get("request")
        image_url = photo.image.url
        return request.build_absolute_uri(image_url) if request else image_url


def validate_gallery_image(image):
    if image.size > 10 * 1024 * 1024:
        raise serializers.ValidationError("Each photo must be 10 MB or smaller.")
    try:
        with Image.open(image) as decoded:
            if decoded.format not in {"JPEG", "PNG", "WEBP"}:
                raise serializers.ValidationError("Upload JPEG, PNG, or WebP photos only.")
            if decoded.width > 12000 or decoded.height > 12000 or decoded.width * decoded.height > 40000000:
                raise serializers.ValidationError("Photo dimensions are too large.")
            decoded.verify()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as error:
        raise serializers.ValidationError("One or more files are not valid image files.") from error
    image.seek(0)
    return image


class GalleryPhotoUpdateSerializer(serializers.ModelSerializer):
    category_title = serializers.CharField(source="category.title", read_only=True)
    image_url = serializers.SerializerMethodField()
    category = serializers.SlugRelatedField(
        queryset=GalleryCategory.objects.all(),
        slug_field="slug",
        required=False,
    )

    class Meta:
        model = GalleryPhoto
        fields = ["id", "category", "category_title", "title", "image", "image_url", "created_at"]
        read_only_fields = ["id", "category_title", "image_url", "created_at"]

    def validate_title(self, value):
        value = " ".join(value.split())
        if not value:
            raise serializers.ValidationError("Enter a photo title.")
        return value

    def validate_image(self, image):
        return validate_gallery_image(image)

    def get_image_url(self, photo):
        request = self.context.get("request")
        image_url = photo.image.url
        return request.build_absolute_uri(image_url) if request else image_url


class GalleryPhotoUploadSerializer(serializers.Serializer):
    category = serializers.SlugRelatedField(queryset=GalleryCategory.objects.all(), slug_field="slug")
    images = serializers.ListField(
        child=serializers.ImageField(),
        allow_empty=False,
        max_length=20,
    )

    def validate_images(self, images):
        for image in images:
            validate_gallery_image(image)
        return images

    def create(self, validated_data):
        category = validated_data["category"]
        photos = []
        for image in validated_data["images"]:
            title = Path(image.name).stem.replace("_", " ").replace("-", " ").strip() or category.title
            photos.append(GalleryPhoto.objects.create(category=category, image=image, title=title[:120]))
        return photos


class StaffCreateSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    email = serializers.EmailField(required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, trim_whitespace=False, min_length=8)

    def validate_username(self, value):
        user_model = get_user_model()
        if user_model.objects.filter(**{user_model.USERNAME_FIELD: value}).exists():
            raise serializers.ValidationError("That username is already in use.")
        return value

    def validate(self, attrs):
        user = get_user_model()(username=attrs["username"], email=attrs.get("email", ""))
        try:
            validate_password(attrs["password"], user=user)
        except DjangoValidationError as error:
            raise serializers.ValidationError({"password": list(error.messages)}) from error
        return attrs

    def create(self, validated_data):
        user_model = get_user_model()
        return user_model.objects.create_user(
            username=validated_data["username"],
            email=validated_data.get("email", ""),
            password=validated_data["password"],
            is_staff=True,
        )
