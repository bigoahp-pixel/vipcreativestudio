import json
import logging
import urllib.error
import urllib.request

from django.conf import settings
from django.core.mail import EmailMultiAlternatives

from .models import Booking

logger = logging.getLogger("bookings")


def _booking_summary(booking):
    return (
        f"Reference: {booking.reference}\n"
        f"Client: {booking.full_name}\n"
        f"Email: {booking.email}\n"
        f"Phone: {booking.phone}\n"
        f"Service: {booking.service}\n"
        f"Preferred date: {booking.appointment_date} at {booking.appointment_time}\n"
        f"Location: {booking.location or 'Not provided'}\n"
        f"Budget: {booking.budget or 'Not provided'}\n"
        f"People: {booking.people_count or 'Not provided'}\n"
        f"Requirements: {booking.requirements or 'None'}\n"
        f"Status: {booking.get_status_display()}"
    )


def send_booking_emails(booking):
    if not settings.DEFAULT_FROM_EMAIL:
        logger.warning("Email not configured for booking %s: DEFAULT_FROM_EMAIL is missing", booking.reference)
        if booking.owner_email_status != "sent":
            booking.owner_email_status = "not_configured"
        if booking.client_email_status != "sent":
            booking.client_email_status = "not_configured"
        booking.save(update_fields=["owner_email_status", "client_email_status", "updated_at"])
        return

    if booking.owner_email_status != "sent":
        if not settings.STUDIO_EMAIL:
            logger.warning("Owner email not configured for booking %s: STUDIO_EMAIL is missing", booking.reference)
            booking.owner_email_status = "not_configured"
        else:
            try:
                admin_url = f"{settings.PUBLIC_ADMIN_URL.rstrip('/')}/admin" if settings.PUBLIC_ADMIN_URL else "Sign in to the studio admin dashboard"
                message = EmailMultiAlternatives(
                    subject=f"New booking request {booking.reference}",
                    body=f"{_booking_summary(booking)}\n\nManage bookings: {admin_url}",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=[settings.STUDIO_EMAIL],
                    reply_to=[booking.email],
                )
                message.send(fail_silently=False)
                booking.owner_email_status = "sent"
            except Exception:
                logger.exception("Owner email failed for booking %s", booking.reference)
                booking.owner_email_status = "failed"

    if booking.client_email_status != "sent":
        try:
            message = EmailMultiAlternatives(
                subject=f"We received your V.I.P Creative Studio request — {booking.reference}",
                body=(
                    f"Hello {booking.full_name},\n\nWe received your request for {booking.service} "
                    f"on {booking.appointment_date} at {booking.appointment_time}.\n\n"
                    f"Your reference is {booking.reference}. Your appointment is pending until "
                    "our studio confirms it. We will contact you as soon as possible.\n\n"
                    "V.I.P Creative Studio\nLet Light Leads the Lens"
                ),
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[booking.email],
            )
            message.send(fail_silently=False)
            booking.client_email_status = "sent"
        except Exception:
            logger.exception("Client acknowledgement email failed for booking %s", booking.reference)
            booking.client_email_status = "failed"
    booking.save(update_fields=["owner_email_status", "client_email_status", "updated_at"])


def send_owner_whatsapp(booking):
    token = settings.WHATSAPP_ACCESS_TOKEN
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    template = getattr(settings, "WHATSAPP_TEMPLATE_NAME", "")
    if not (token and phone_id and template):
        booking.whatsapp_status = "manual_link"
        booking.save(update_fields=["whatsapp_status", "updated_at"])
        return

    payload = {
        "messaging_product": "whatsapp",
        "to": settings.WHATSAPP_PHONE,
        "type": "template",
        "template": {
            "name": template,
            "language": {"code": getattr(settings, "WHATSAPP_TEMPLATE_LANGUAGE", "en_US")},
            "components": [{
                "type": "body",
                "parameters": [
                    {"type": "text", "text": booking.reference},
                    {"type": "text", "text": booking.full_name[:120]},
                    {"type": "text", "text": booking.service[:50]},
                    {"type": "text", "text": f"{booking.appointment_date} {booking.appointment_time}"},
                    {"type": "text", "text": booking.phone},
                ],
            }],
        },
    }
    endpoint = f"https://graph.facebook.com/{settings.WHATSAPP_API_VERSION}/{phone_id}/messages"
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            result = json.loads(response.read().decode("utf-8"))
        messages = result.get("messages", []) if isinstance(result, dict) else []
        message_id = messages[0].get("id") if messages and isinstance(messages[0], dict) else None
        if not isinstance(message_id, str) or not message_id:
            raise ValueError("WhatsApp provider response did not include a message ID")
        booking.whatsapp_message_id = message_id[:120]
        booking.whatsapp_status = "accepted"
    except (urllib.error.URLError, TimeoutError, ValueError, json.JSONDecodeError):
        logger.exception("WhatsApp provider submission failed for booking %s", booking.reference)
        booking.whatsapp_status = "failed"
    booking.save(update_fields=["whatsapp_message_id", "whatsapp_status", "updated_at"])


def send_status_update(booking, rescheduled=False, send_email=True, send_whatsapp=True):
    status_text = {
        "confirmed": "approved",
        "cancelled": "declined",
        "completed": "marked completed",
        "pending": "returned to pending",
    }.get(booking.status, booking.get_status_display().lower())
    update_text = (
        "Your appointment has been rescheduled by our studio."
        if rescheduled
        else f"Your booking request has been {status_text}."
    )
    appointment = f"{booking.appointment_date} at {booking.appointment_time}"

    if send_email and not settings.DEFAULT_FROM_EMAIL:
        logger.warning("Status email not configured for booking %s", booking.reference)
        booking.status_email_status = "not_configured"
    elif send_email:
        try:
            message = EmailMultiAlternatives(
                subject=f"Booking {booking.reference} {('rescheduled' if rescheduled else status_text)}",
                body=(
                    f"Hello {booking.full_name},\n\n{update_text}\n\n"
                    f"Reference: {booking.reference}\n"
                    f"Service: {booking.service}\n"
                    f"Status: {booking.get_status_display()}\n"
                    f"Appointment: {appointment}\n\n"
                    "Please contact V.I.P Creative Studio if you have questions."
                ),
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[booking.email],
            )
            message.send(fail_silently=False)
            booking.status_email_status = "sent"
        except Exception:
            logger.exception("Status update email failed for booking %s", booking.reference)
            booking.status_email_status = "failed"

    status_template = getattr(settings, "WHATSAPP_STATUS_TEMPLATE_NAME", "")
    if send_whatsapp:
        booking.status_whatsapp_message_id = ""
    if send_whatsapp and booking.preferred_contact != Booking.ContactMethod.WHATSAPP:
        booking.status_whatsapp_status = "not_preferred"
    elif send_whatsapp and not (settings.WHATSAPP_ACCESS_TOKEN and settings.WHATSAPP_PHONE_NUMBER_ID and status_template):
        booking.status_whatsapp_status = "not_configured"
    elif send_whatsapp:
        payload = {
            "messaging_product": "whatsapp",
            "to": booking.phone.lstrip("+"),
            "type": "template",
            "template": {
                "name": status_template,
                "language": {"code": getattr(settings, "WHATSAPP_STATUS_TEMPLATE_LANGUAGE", "en_US")},
                "components": [{
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": booking.reference},
                        {"type": "text", "text": booking.full_name[:120]},
                        {"type": "text", "text": update_text[:200]},
                        {"type": "text", "text": booking.service[:50]},
                        {"type": "text", "text": appointment[:100]},
                    ],
                }],
            },
        }
        endpoint = f"https://graph.facebook.com/{settings.WHATSAPP_API_VERSION}/{settings.WHATSAPP_PHONE_NUMBER_ID}/messages"
        request = urllib.request.Request(
            endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {settings.WHATSAPP_ACCESS_TOKEN}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                result = json.loads(response.read().decode("utf-8"))
            messages = result.get("messages", []) if isinstance(result, dict) else []
            message_id = messages[0].get("id") if messages and isinstance(messages[0], dict) else None
            if not isinstance(message_id, str) or not message_id:
                raise ValueError("WhatsApp provider response did not include a message ID")
            booking.status_whatsapp_message_id = message_id[:120]
            booking.status_whatsapp_status = "accepted"
        except (urllib.error.URLError, TimeoutError, ValueError, json.JSONDecodeError):
            logger.exception("Status WhatsApp notification failed for booking %s", booking.reference)
            booking.status_whatsapp_status = "failed"

    if send_email or send_whatsapp:
        booking.status_notification_rescheduled = rescheduled
    booking.save(update_fields=[
        "status_email_status", "status_whatsapp_status",
        "status_whatsapp_message_id", "status_notification_rescheduled", "updated_at",
    ])
