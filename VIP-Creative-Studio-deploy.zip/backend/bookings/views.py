import csv
import hashlib
import hmac
import json
import logging
import uuid

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.db import IntegrityError, transaction
from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_protect
from django.views.decorators.http import require_GET
from rest_framework import generics, status
from rest_framework.permissions import AllowAny, IsAdminUser
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle
from rest_framework.views import APIView

from .models import Booking, GalleryCategory, GalleryPhoto
from .notifications import send_booking_emails, send_owner_whatsapp, send_status_update
from .serializers import (
    BookingAdminSerializer,
    BookingCreateSerializer,
    GalleryCategoryCreateSerializer,
    GalleryCategorySerializer,
    GalleryPhotoSerializer,
    GalleryPhotoUpdateSerializer,
    GalleryPhotoUploadSerializer,
    StaffCreateSerializer,
)

logger = logging.getLogger("bookings")


class BookingThrottle(AnonRateThrottle):
    scope = "booking"


class BookingCreateView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [BookingThrottle]

    def post(self, request):
        serializer = BookingCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        fingerprint = hashlib.sha256(
            json.dumps(serializer.validated_data, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        try:
            idempotency_key = uuid.UUID(request.headers.get("Idempotency-Key", ""))
        except ValueError:
            if request.headers.get("Idempotency-Key"):
                return Response({"detail": "Invalid submission key."}, status=status.HTTP_400_BAD_REQUEST)
            idempotency_key = uuid.uuid4()
        existing = Booking.objects.filter(idempotency_key=idempotency_key).first()
        if existing:
            if existing.request_fingerprint != fingerprint:
                return Response({"detail": "This submission key was already used for different booking details."}, status=status.HTTP_409_CONFLICT)
            return Response(self.response_data(existing), status=status.HTTP_200_OK)
        try:
            with transaction.atomic():
                booking = serializer.save(idempotency_key=idempotency_key, request_fingerprint=fingerprint)
        except IntegrityError:
            existing = Booking.objects.filter(idempotency_key=idempotency_key).first()
            if not existing:
                raise
            if existing.request_fingerprint != fingerprint:
                return Response({"detail": "This submission key was already used for different booking details."}, status=status.HTTP_409_CONFLICT)
            return Response(self.response_data(existing), status=status.HTTP_200_OK)
        send_booking_emails(booking)
        send_owner_whatsapp(booking)
        return Response(self.response_data(booking), status=status.HTTP_201_CREATED)

    @staticmethod
    def response_data(booking):
        from urllib.parse import quote

        summary = (
            f"Hello V.I.P Creative Studio, I submitted booking request {booking.reference}.\n"
            f"Name: {booking.full_name}\nService: {booking.service}\n"
            f"Date: {booking.appointment_date} at {booking.appointment_time}\n"
            f"Location: {booking.location or 'Not specified'}\n"
            f"Budget: {booking.budget or 'Not specified'}\n"
            f"People: {booking.people_count or 'Not specified'}\n"
            f"Requirements: {booking.requirements or 'None'}\n"
            f"Phone: {booking.phone}\nEmail: {booking.email}\n"
            "Status: Pending studio confirmation."
        )
        return {
            "reference": booking.reference,
            "status": booking.status,
            "owner_email_status": booking.owner_email_status,
            "client_email_status": booking.client_email_status,
            "whatsapp_status": booking.whatsapp_status,
            "whatsapp_url": f"https://wa.me/{settings.WHATSAPP_PHONE}?text={quote(summary, safe='')}",
            "message": "Your request was saved and is pending studio confirmation.",
        }


@ensure_csrf_cookie
@require_GET
def csrf_cookie(request):
    return JsonResponse({"csrfToken": get_token(request)})


@csrf_protect
def admin_login(request):
    if request.method != "POST":
        return JsonResponse({"detail": "Method not allowed."}, status=405)
    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({"detail": "Invalid request body."}, status=400)
    if not isinstance(data, dict):
        return JsonResponse({"detail": "Invalid request body."}, status=400)
    username = data.get("username", "")
    password = data.get("password", "")
    if not isinstance(username, str) or not isinstance(password, str):
        return JsonResponse({"detail": "Invalid request body."}, status=400)
    user = authenticate(request, username=username, password=password)
    if user is None or not user.is_active or not user.is_staff:
        return JsonResponse({"detail": "Invalid staff credentials."}, status=401)
    login(request, user)
    return JsonResponse({"username": user.get_username(), "is_superuser": user.is_superuser})


@csrf_protect
def admin_logout(request):
    if request.method != "POST":
        return JsonResponse({"detail": "Method not allowed."}, status=405)
    logout(request)
    return JsonResponse({"message": "Signed out."})


class AdminSessionView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        return Response({
            "username": request.user.get_username(),
            "is_staff": True,
            "is_superuser": request.user.is_superuser,
        })


class GalleryCategoryListView(generics.ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = GalleryCategorySerializer
    queryset = GalleryCategory.objects.all()


class AdminGalleryCategoryListCreateView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        return Response(GalleryCategorySerializer(GalleryCategory.objects.all(), many=True).data)

    def post(self, request):
        serializer = GalleryCategoryCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        category = serializer.save()
        return Response(GalleryCategorySerializer(category).data, status=status.HTTP_201_CREATED)


class AdminGalleryCategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAdminUser]
    serializer_class = GalleryCategorySerializer
    queryset = GalleryCategory.objects.all()
    lookup_field = "slug"

    def perform_destroy(self, instance):
        if instance.photos.exists():
            raise ValidationError({"detail": "Move or delete this category's photos before deleting the category."})
        instance.delete()


class GalleryPhotoListView(generics.ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = GalleryPhotoSerializer

    def get_queryset(self):
        queryset = GalleryPhoto.objects.select_related("category").all()
        category = self.request.query_params.get("category")
        return queryset.filter(category__slug=category) if category else queryset


class AdminGalleryPhotoListCreateView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        photos = GalleryPhoto.objects.select_related("category").all()
        return Response(GalleryPhotoSerializer(photos, many=True, context={"request": request}).data)

    def post(self, request):
        serializer = GalleryPhotoUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        photos = serializer.save()
        return Response(
            GalleryPhotoSerializer(photos, many=True, context={"request": request}).data,
            status=status.HTTP_201_CREATED,
        )


class AdminGalleryPhotoDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAdminUser]
    serializer_class = GalleryPhotoUpdateSerializer
    queryset = GalleryPhoto.objects.all()

    def perform_update(self, serializer):
        previous_image = self.get_object().image
        photo = serializer.save()
        if "image" in serializer.validated_data and previous_image.name != photo.image.name:
            previous_image.delete(save=False)

    def perform_destroy(self, instance):
        instance.image.delete(save=False)
        instance.delete()


class StaffManagementView(APIView):
    permission_classes = [IsAdminUser]

    def initial(self, request, *args, **kwargs):
        super().initial(request, *args, **kwargs)
        if not request.user.is_superuser:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied("Only a studio superuser can manage staff accounts.")

    def get(self, request):
        user_model = get_user_model()
        staff = user_model.objects.filter(is_staff=True).order_by("username")
        return Response([
            {
                "id": user.pk,
                "username": user.get_username(),
                "email": user.email,
                "is_active": user.is_active,
                "is_superuser": user.is_superuser,
            }
            for user in staff
        ])

    def post(self, request):
        serializer = StaffCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(
            {"id": user.pk, "username": user.get_username(), "email": user.email, "is_active": user.is_active},
            status=status.HTTP_201_CREATED,
        )


class BookingListView(generics.ListAPIView):
    permission_classes = [IsAdminUser]
    serializer_class = BookingAdminSerializer

    def get_queryset(self):
        queryset = Booking.objects.all()
        for field in ("status", "service"):
            value = self.request.query_params.get(field)
            if value:
                queryset = queryset.filter(**{field: value})
        date_from = self.request.query_params.get("date_from")
        date_to = self.request.query_params.get("date_to")
        if date_from:
            if not self._is_date(date_from):
                raise ValidationError({"date_from": "Use YYYY-MM-DD format."})
            queryset = queryset.filter(appointment_date__gte=date_from)
        if date_to:
            if not self._is_date(date_to):
                raise ValidationError({"date_to": "Use YYYY-MM-DD format."})
            queryset = queryset.filter(appointment_date__lte=date_to)
        return queryset

    @staticmethod
    def _is_date(value):
        from datetime import date

        try:
            date.fromisoformat(value)
            return True
        except ValueError:
            return False


class BookingDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAdminUser]
    serializer_class = BookingAdminSerializer
    queryset = Booking.objects.all()

    def perform_update(self, serializer):
        previous = self.get_object()
        old_status = previous.status
        old_date = previous.appointment_date
        old_time = previous.appointment_time
        booking = serializer.save()
        rescheduled = booking.appointment_date != old_date or booking.appointment_time != old_time
        if booking.status != old_status or rescheduled:
            send_status_update(booking, rescheduled=rescheduled)


class RetryEmailView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request, pk):
        booking = get_object_or_404(Booking, pk=pk)
        if booking.owner_email_status in ("pending", "failed", "not_configured") or booking.client_email_status in ("pending", "failed", "not_configured"):
            send_booking_emails(booking)
        return Response({
            "owner_email_status": booking.owner_email_status,
            "client_email_status": booking.client_email_status,
        })


class RetryStatusNotificationView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request, pk):
        booking = get_object_or_404(Booking, pk=pk)
        retry_email = booking.status_email_status in ("failed", "not_configured")
        retry_whatsapp = booking.status_whatsapp_status in ("failed", "not_configured")
        if retry_email or retry_whatsapp:
            send_status_update(
                booking,
                rescheduled=booking.status_notification_rescheduled,
                send_email=retry_email,
                send_whatsapp=retry_whatsapp,
            )
        booking.refresh_from_db()
        return Response({
            "status_email_status": booking.status_email_status,
            "status_whatsapp_status": booking.status_whatsapp_status,
        })


class BookingExportView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = 'attachment; filename="vip-bookings.csv"'
        writer = csv.writer(response)
        writer.writerow(["Reference", "Name", "Email", "Phone", "Service", "Date", "Time", "Location", "Budget", "Status"])
        for booking in Booking.objects.all().iterator():
            writer.writerow([
                *[
                    self._safe_csv_value(value) for value in (
                        booking.reference, booking.full_name, booking.email, booking.phone,
                        booking.service, booking.appointment_date, booking.appointment_time,
                        booking.location, booking.budget, booking.status,
                    )
                ],
            ])
        return response

    @staticmethod
    def _safe_csv_value(value):
        text = str(value)
        if text.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
            return "'" + text
        return text


@require_GET
def whatsapp_webhook_verify(request):
    if (
        request.GET.get("hub.mode") == "subscribe"
        and request.GET.get("hub.verify_token") == settings.WHATSAPP_WEBHOOK_VERIFY_TOKEN
        and settings.WHATSAPP_WEBHOOK_VERIFY_TOKEN
    ):
        return HttpResponse(request.GET.get("hub.challenge", ""), content_type="text/plain")
    return HttpResponse(status=403)


class WhatsAppWebhookView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        signature = request.headers.get("X-Hub-Signature-256", "")
        secret = settings.WHATSAPP_APP_SECRET
        expected = "sha256=" + hmac.new(secret.encode(), request.body, hashlib.sha256).hexdigest() if secret else ""
        if not expected or not hmac.compare_digest(signature, expected):
            return Response({"detail": "Invalid webhook signature."}, status=403)
        try:
            events = request.data.get("entry", [])
            for entry in events:
                for change in entry.get("changes", []):
                    value = change.get("value", {})
                    for item in value.get("statuses", []):
                        message_id = item.get("id")
                        provider_status = item.get("status")
                        if not isinstance(message_id, str) or not isinstance(provider_status, str):
                            continue
                        Booking.objects.filter(whatsapp_message_id=message_id).update(
                            whatsapp_status=provider_status[:30]
                        )
                        Booking.objects.filter(status_whatsapp_message_id=message_id).update(
                            status_whatsapp_status=provider_status[:30]
                        )
        except (AttributeError, TypeError, ValueError):
            logger.warning("Malformed WhatsApp status webhook received")
            return Response({"detail": "Invalid webhook payload."}, status=400)
        return Response({"received": True})
