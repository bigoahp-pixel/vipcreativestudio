from io import BytesIO
import tempfile
import uuid
import hashlib
import hmac
import json
from datetime import timedelta
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse

from django.contrib.auth import get_user_model
from django.core import mail
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.utils import timezone
from PIL import Image
from rest_framework.test import APIClient

from .models import Booking, GalleryCategory, GalleryPhoto


@override_settings(
    EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
    DEFAULT_FROM_EMAIL="studio@example.com",
    STUDIO_EMAIL="owner@example.com",
    WHATSAPP_ACCESS_TOKEN="",
    WHATSAPP_PHONE_NUMBER_ID="",
    WHATSAPP_TEMPLATE_NAME="",
    REST_FRAMEWORK={
        "DEFAULT_THROTTLE_RATES": {"booking": "100/hour", "anon": "1000/hour"},
        "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.AllowAny"],
        "DEFAULT_AUTHENTICATION_CLASSES": ["rest_framework.authentication.SessionAuthentication"],
    },
)
class BookingApiTests(TestCase):
    def setUp(self):
        throttle_patcher = patch("bookings.views.BookingThrottle.allow_request", return_value=True)
        throttle_patcher.start()
        self.addCleanup(throttle_patcher.stop)
        self.client = APIClient()
        self.key = uuid.uuid4()
        self.payload = {
            "full_name": "Amina Deng",
            "email": "amina@example.com",
            "phone": "+211922865522",
            "service": "Portraits",
            "appointment_date": (timezone.localdate() + timedelta(days=2)).isoformat(),
            "appointment_time": "10:30",
            "location": "Thongpiny",
            "budget": "150,000 SSP",
            "people_count": 2,
            "requirements": "Warm natural light",
            "preferred_contact": "whatsapp",
        }

    def submit(self, payload=None, key=None):
        return self.client.post(
            "/api/bookings/",
            payload or self.payload,
            format="json",
            HTTP_IDEMPOTENCY_KEY=str(key or self.key),
        )

    def test_valid_booking_is_saved_and_notifies_both_email_recipients(self):
        response = self.submit()

        self.assertEqual(response.status_code, 201)
        booking = Booking.objects.get()
        self.assertTrue(booking.reference.startswith("VIP-"))
        self.assertEqual(booking.status, Booking.Status.PENDING)
        self.assertEqual(booking.owner_email_status, "sent")
        self.assertEqual(booking.client_email_status, "sent")
        self.assertEqual(len(mail.outbox), 2)
        self.assertIn(booking.reference, mail.outbox[0].body)
        self.assertIn("pending until", mail.outbox[1].body)
        self.assertEqual(response.data["status"], "pending")
        self.assertEqual(response.data["whatsapp_status"], "manual_link")

    def test_birthday_photography_booking_is_accepted(self):
        payload = {**self.payload, "service": "Birthday photography"}

        response = self.submit(payload)

        self.assertEqual(response.status_code, 201)
        self.assertEqual(Booking.objects.get().service, "Birthday photography")

    def test_whatsapp_link_contains_booking_summary(self):
        response = self.submit()
        query = parse_qs(urlparse(response.data["whatsapp_url"]).query)

        self.assertEqual(urlparse(response.data["whatsapp_url"]).netloc, "wa.me")
        self.assertIn("211922865522", urlparse(response.data["whatsapp_url"]).path)
        self.assertIn("Portraits", query["text"][0])
        self.assertIn("Thongpiny", query["text"][0])
        self.assertIn("Pending studio confirmation", query["text"][0])

    def test_repeated_idempotency_key_does_not_create_or_notify_twice(self):
        first = self.submit()
        second = self.submit()

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(Booking.objects.count(), 1)
        self.assertEqual(len(mail.outbox), 2)
        self.assertEqual(first.data["reference"], second.data["reference"])

    def test_idempotency_key_cannot_be_reused_for_different_details(self):
        self.submit()
        changed = {**self.payload, "full_name": "Different Client"}

        response = self.submit(changed)

        self.assertEqual(response.status_code, 409)
        self.assertEqual(Booking.objects.count(), 1)

    def test_past_appointment_is_rejected(self):
        payload = {**self.payload, "appointment_date": (timezone.localdate() - timedelta(days=1)).isoformat()}

        response = self.submit(payload)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Booking.objects.count(), 0)

    def test_invalid_international_phone_is_rejected(self):
        response = self.submit({**self.payload, "phone": "0922865522"})

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Booking.objects.count(), 0)

    def test_international_phone_formats_are_normalized_across_countries(self):
        examples = [
            ("+1 (650) 253-0000", "+16502530000"),
            ("+44 20 7031 3000", "+442070313000"),
            ("0044 20 7031 3000", "+442070313000"),
        ]
        for formatted, normalized in examples:
            with self.subTest(phone=formatted):
                response = self.submit({**self.payload, "phone": formatted}, key=uuid.uuid4())
                self.assertEqual(response.status_code, 201)
                booking = Booking.objects.order_by("-id").first()
                self.assertEqual(booking.phone, normalized)

    def test_phone_without_international_country_code_is_rejected(self):
        response = self.submit({**self.payload, "phone": "(650) 253-0000"})

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Booking.objects.count(), 0)

    def test_booking_api_preflight_allows_the_idempotency_header(self):
        response = self.client.options(
            "/api/bookings/",
            HTTP_ORIGIN="http://localhost:5173",
            HTTP_ACCESS_CONTROL_REQUEST_METHOD="POST",
            HTTP_ACCESS_CONTROL_REQUEST_HEADERS="content-type,idempotency-key",
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Access-Control-Allow-Origin"], "http://localhost:5173")
        self.assertEqual(response["Access-Control-Allow-Credentials"], "true")
        self.assertIn("idempotency-key", response["Access-Control-Allow-Headers"])

    @override_settings(DEFAULT_FROM_EMAIL="", STUDIO_EMAIL="")
    def test_missing_email_configuration_does_not_lose_booking(self):
        response = self.submit()

        self.assertEqual(response.status_code, 201)
        booking = Booking.objects.get()
        self.assertEqual(booking.owner_email_status, "not_configured")
        self.assertEqual(booking.client_email_status, "not_configured")
        self.assertEqual(len(mail.outbox), 0)

    @patch("bookings.notifications.urllib.request.urlopen")
    @override_settings(
        WHATSAPP_ACCESS_TOKEN="server-only-token",
        WHATSAPP_PHONE_NUMBER_ID="studio-phone-id",
        WHATSAPP_TEMPLATE_NAME="booking_notice",
    )
    def test_whatsapp_cloud_api_requires_provider_acceptance_and_uses_booking_details(self, mocked_urlopen):
        mocked_urlopen.return_value.__enter__.return_value.read.return_value = b'{"messages":[{"id":"wamid.test-123"}]}'

        response = self.submit()

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data["whatsapp_status"], "accepted")
        booking = Booking.objects.get()
        self.assertEqual(booking.whatsapp_message_id, "wamid.test-123")
        request = mocked_urlopen.call_args.args[0]
        payload = json.loads(request.data.decode("utf-8"))
        self.assertEqual(payload["to"], "211922865522")
        self.assertEqual(payload["template"]["components"][0]["parameters"][0]["text"], booking.reference)
        self.assertEqual(payload["template"]["components"][0]["parameters"][2]["text"], "Portraits")

    @override_settings(WHATSAPP_APP_SECRET="webhook-secret")
    def test_whatsapp_status_webhook_requires_signature_and_records_delivery(self):
        booking = self.submit()
        record = Booking.objects.get()
        record.whatsapp_message_id = "wamid.callback-1"
        record.whatsapp_status = "accepted"
        record.status_whatsapp_message_id = "wamid.status-callback-1"
        record.status_whatsapp_status = "accepted"
        record.save(update_fields=[
            "whatsapp_message_id", "whatsapp_status",
            "status_whatsapp_message_id", "status_whatsapp_status",
        ])
        payload = json.dumps({"entry": [{"changes": [{"value": {"statuses": [
            {"id": record.whatsapp_message_id, "status": "delivered"},
            {"id": record.status_whatsapp_message_id, "status": "read"},
        ]}}]}]})
        signature = "sha256=" + hmac.new(b"webhook-secret", payload.encode("utf-8"), hashlib.sha256).hexdigest()

        rejected = self.client.post("/api/whatsapp/webhook/", payload, content_type="application/json")
        accepted = self.client.post(
            "/api/whatsapp/webhook/", payload, content_type="application/json",
            HTTP_X_HUB_SIGNATURE_256=signature,
        )

        self.assertEqual(booking.status_code, 201)
        self.assertEqual(rejected.status_code, 403)
        self.assertEqual(accepted.status_code, 200)
        record.refresh_from_db()
        self.assertEqual(record.whatsapp_status, "delivered")
        self.assertEqual(record.status_whatsapp_status, "read")

    def test_approval_and_decline_email_the_client_and_record_delivery(self):
        self.submit()
        booking = Booking.objects.get()
        staff = get_user_model().objects.create_user(username="decision-staff", password="safe-password", is_staff=True)
        self.client.force_authenticate(user=staff)

        approved = self.client.patch(
            f"/api/admin/bookings/{booking.pk}/",
            {"status": "confirmed"},
            format="json",
        )
        booking.refresh_from_db()
        self.assertEqual(approved.status_code, 200)
        self.assertEqual(booking.status, Booking.Status.CONFIRMED)
        self.assertEqual(booking.status_email_status, "sent")
        self.assertEqual(booking.status_whatsapp_status, "not_configured")
        self.assertIn("approved", mail.outbox[-1].body)

        declined = self.client.patch(
            f"/api/admin/bookings/{booking.pk}/",
            {"status": "cancelled"},
            format="json",
        )
        booking.refresh_from_db()
        self.assertEqual(declined.status_code, 200)
        self.assertEqual(booking.status, Booking.Status.CANCELLED)
        self.assertEqual(booking.status_email_status, "sent")
        self.assertIn("declined", mail.outbox[-1].body)

    def test_status_notification_failure_and_retry_are_reported(self):
        self.submit()
        booking = Booking.objects.get()
        staff = get_user_model().objects.create_user(username="retry-staff", password="safe-password", is_staff=True)
        self.client.force_authenticate(user=staff)
        with patch("bookings.notifications.EmailMultiAlternatives.send", side_effect=OSError("SMTP unavailable")):
            failed = self.client.patch(
                f"/api/admin/bookings/{booking.pk}/",
                {"status": "confirmed"},
                format="json",
            )
        booking.refresh_from_db()
        self.assertEqual(failed.status_code, 200)
        self.assertEqual(booking.status_email_status, "failed")

        with override_settings(DEFAULT_FROM_EMAIL=""):
            retried = self.client.post(f"/api/admin/bookings/{booking.pk}/retry-status-notification/")
        booking.refresh_from_db()
        self.assertEqual(retried.status_code, 200)
        self.assertEqual(retried.data["status_email_status"], "not_configured")
        self.assertEqual(retried.data["status_whatsapp_status"], "not_configured")
        self.assertEqual(booking.status_email_status, "not_configured")

    @patch("bookings.notifications.urllib.request.urlopen")
    def test_retry_sends_only_the_failed_status_channel(self, mocked_urlopen):
        self.submit()
        booking = Booking.objects.get()
        staff = get_user_model().objects.create_user(username="channel-retry-staff", password="safe-password", is_staff=True)
        self.client.force_authenticate(user=staff)
        self.client.patch(
            f"/api/admin/bookings/{booking.pk}/",
            {"status": "confirmed"},
            format="json",
        )
        self.assertEqual(len(mail.outbox), 3)
        booking.refresh_from_db()
        self.assertEqual(booking.status_email_status, "sent")
        self.assertEqual(booking.status_whatsapp_status, "not_configured")
        mocked_urlopen.return_value.__enter__.return_value.read.return_value = b'{"messages":[{"id":"wamid.retry-status-1"}]}'

        with override_settings(
            WHATSAPP_ACCESS_TOKEN="client-status-token",
            WHATSAPP_PHONE_NUMBER_ID="studio-phone-id",
            WHATSAPP_STATUS_TEMPLATE_NAME="booking_status_update",
        ):
            retried = self.client.post(f"/api/admin/bookings/{booking.pk}/retry-status-notification/")

        booking.refresh_from_db()
        self.assertEqual(retried.status_code, 200)
        self.assertEqual(booking.status_email_status, "sent")
        self.assertEqual(booking.status_whatsapp_status, "accepted")
        self.assertEqual(len(mail.outbox), 3)
        self.assertEqual(mocked_urlopen.call_count, 1)

    @patch("bookings.notifications.urllib.request.urlopen")
    @override_settings(
        WHATSAPP_ACCESS_TOKEN="client-status-token",
        WHATSAPP_PHONE_NUMBER_ID="studio-phone-id",
        WHATSAPP_STATUS_TEMPLATE_NAME="booking_status_update",
    )
    def test_approval_sends_client_whatsapp_template_and_tracks_provider_acceptance(self, mocked_urlopen):
        self.submit()
        booking = Booking.objects.get()
        staff = get_user_model().objects.create_user(username="whatsapp-staff", password="safe-password", is_staff=True)
        self.client.force_authenticate(user=staff)
        mocked_urlopen.return_value.__enter__.return_value.read.return_value = b'{"messages":[{"id":"wamid.client-status-1"}]}'

        response = self.client.patch(
            f"/api/admin/bookings/{booking.pk}/",
            {"status": "confirmed"},
            format="json",
        )

        booking.refresh_from_db()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(booking.status_whatsapp_status, "accepted")
        self.assertEqual(booking.status_whatsapp_message_id, "wamid.client-status-1")
        payload = json.loads(mocked_urlopen.call_args.args[0].data.decode("utf-8"))
        self.assertEqual(payload["to"], "211922865522")
        self.assertEqual(payload["template"]["name"], "booking_status_update")
        parameters = payload["template"]["components"][0]["parameters"]
        self.assertEqual(parameters[0]["text"], booking.reference)
        self.assertEqual(parameters[2]["text"], "Your booking request has been approved.")

    def test_private_booking_list_is_staff_only_and_staff_can_update_status(self):
        booking = self.submit()
        self.assertEqual(booking.status_code, 201)
        self.client.logout()
        self.assertIn(self.client.get("/api/admin/bookings/").status_code, (401, 403))
        self.assertIn(self.client.get(f"/api/admin/bookings/{Booking.objects.get().pk}/").status_code, (401, 403))

        user_model = get_user_model()
        regular_user = user_model.objects.create_user(username="client", password="client-password")
        self.client.force_authenticate(user=regular_user)
        self.assertEqual(self.client.get("/api/admin/bookings/").status_code, 403)

        staff = user_model.objects.create_user(username="studio", password="studio-password", is_staff=True)
        self.client.force_authenticate(user=staff)
        record = Booking.objects.get()
        listing = self.client.get("/api/admin/bookings/")
        self.assertEqual(listing.status_code, 200)
        self.assertEqual(len(listing.data), 1)
        csrf_client = APIClient(enforce_csrf_checks=True)
        stale_csrf = csrf_client.get("/api/csrf/").json()["csrfToken"]
        staff.set_password("safe-password")
        staff.save(update_fields=["password"])
        login_response = csrf_client.post(
            "/api/admin/login/",
            {"username": "studio", "password": "safe-password"},
            format="json",
            HTTP_X_CSRFTOKEN=stale_csrf,
        )
        self.assertEqual(login_response.status_code, 200)
        patch_url = f"/api/admin/bookings/{record.pk}/"
        payload = {
            "status": "confirmed",
            "appointment_date": (timezone.localdate() + timedelta(days=3)).isoformat(),
        }
        denied = csrf_client.patch(
            patch_url,
            payload,
            format="json",
            HTTP_X_CSRFTOKEN=stale_csrf,
        )
        csrf_token = csrf_client.get("/api/csrf/").json()["csrfToken"]
        response = csrf_client.patch(
            patch_url,
            payload,
            format="json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )
        record.refresh_from_db()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(denied.status_code, 403)
        self.assertEqual(record.status, Booking.Status.CONFIRMED)
        self.assertEqual(record.appointment_date, timezone.localdate() + timedelta(days=3))
        self.assertEqual(len(mail.outbox), 3)
        self.assertIn("rescheduled", mail.outbox[-1].body)

    def test_staff_can_edit_booking_details_and_delete_booking(self):
        self.submit()
        booking = Booking.objects.get()
        staff = get_user_model().objects.create_user(username="booking-editor", password="safe-password", is_staff=True)
        self.client.force_authenticate(user=staff)

        updated = self.client.patch(
            f"/api/admin/bookings/{booking.pk}/",
            {
                "full_name": "Amina Deng Kuol",
                "phone": "00211 922 865 522",
                "service": "Birthday photography",
                "location": "Magateen",
                "people_count": 4,
            },
            format="json",
        )
        booking.refresh_from_db()
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(booking.full_name, "Amina Deng Kuol")
        self.assertEqual(booking.phone, "+211922865522")
        self.assertEqual(booking.service, "Birthday photography")
        self.assertEqual(booking.location, "Magateen")
        self.assertEqual(booking.people_count, 4)

        removed = self.client.delete(f"/api/admin/bookings/{booking.pk}/")
        self.assertEqual(removed.status_code, 204)
        self.assertFalse(Booking.objects.filter(pk=booking.pk).exists())

    def test_invalid_admin_booking_phone_is_rejected_without_changing_booking(self):
        self.submit()
        booking = Booking.objects.get()
        staff = get_user_model().objects.create_user(username="booking-validator", password="safe-password", is_staff=True)
        self.client.force_authenticate(user=staff)

        response = self.client.patch(
            f"/api/admin/bookings/{booking.pk}/",
            {"phone": "555-123"},
            format="json",
        )

        self.assertEqual(response.status_code, 400)
        booking.refresh_from_db()
        self.assertEqual(booking.phone, "+211922865522")

    def test_gallery_categories_are_publicly_listed_and_staff_can_manage_them(self):
        public_response = self.client.get("/api/gallery/categories/")
        self.assertEqual(public_response.status_code, 200)
        self.assertTrue(any(category["slug"] == "birthdays" for category in public_response.data))

        user_model = get_user_model()
        staff = user_model.objects.create_user(username="category-staff", password="unused-pass-123", is_staff=True)
        self.client.force_authenticate(user=staff)
        created = self.client.post(
            "/api/admin/gallery/categories/",
            {"title": "Behind the scenes", "service": "Events"},
            format="json",
        )
        self.assertEqual(created.status_code, 201)
        self.assertEqual(created.data["slug"], "behind-the-scenes")
        category = GalleryCategory.objects.get(slug="behind-the-scenes")
        updated = self.client.patch(
            f"/api/admin/gallery/categories/{category.slug}/",
            {"title": "Studio stories", "service": ""},
            format="json",
        )
        self.assertEqual(updated.status_code, 200)
        category.refresh_from_db()
        self.assertEqual(category.title, "Studio stories")

    def test_only_superusers_can_create_staff_accounts(self):
        user_model = get_user_model()
        staff = user_model.objects.create_user(username="regular-staff", password="unused-pass-123", is_staff=True)
        self.client.force_authenticate(user=staff)
        denied = self.client.post(
            "/api/admin/staff/",
            {"username": "new-photographer", "password": "Oceans!Velvet!7824-Camera"},
            format="json",
        )
        self.assertEqual(denied.status_code, 403)
        self.assertFalse(user_model.objects.filter(username="new-photographer").exists())

        superuser = user_model.objects.create_superuser(username="studio-owner", password="owner-pass-123")
        self.client.force_authenticate(user=superuser)
        created = self.client.post(
            "/api/admin/staff/",
            {"username": "new-photographer", "email": "photographer@example.com", "password": "Oceans!Velvet!7824-Camera"},
            format="json",
        )
        self.assertEqual(created.status_code, 201)
        new_staff = user_model.objects.get(username="new-photographer")
        self.assertTrue(new_staff.is_staff)
        self.assertFalse(new_staff.is_superuser)
        self.assertTrue(new_staff.check_password("Oceans!Velvet!7824-Camera"))

    def test_gallery_photo_upload_is_staff_only_public_and_removable(self):
        category = GalleryCategory.objects.get(slug="portraits")
        buffer = BytesIO()
        Image.new("RGB", (24, 24), color=(180, 140, 90)).save(buffer, format="JPEG")
        image_bytes = buffer.getvalue()

        denied = self.client.post(
            "/api/admin/gallery/photos/",
            {"category": category.slug, "images": [SimpleUploadedFile("portrait.jpg", image_bytes, "image/jpeg")]},
            format="multipart",
        )
        self.assertIn(denied.status_code, (401, 403))
        self.assertEqual(GalleryPhoto.objects.count(), 0)

        user_model = get_user_model()
        staff = user_model.objects.create_user(username="gallery-admin", password="unused-pass-123", is_staff=True)
        self.client.force_authenticate(user=staff)
        with tempfile.TemporaryDirectory() as media_root, override_settings(MEDIA_ROOT=media_root):
            invalid = self.client.post(
                "/api/admin/gallery/photos/",
                {"category": category.slug, "images": [SimpleUploadedFile("not-image.jpg", b"not an image", "image/jpeg")]},
                format="multipart",
            )
            self.assertEqual(invalid.status_code, 400)

            second_buffer = BytesIO()
            Image.new("RGB", (18, 18), color=(90, 140, 180)).save(second_buffer, format="JPEG")
            uploaded = self.client.post(
                "/api/admin/gallery/photos/",
                {"category": category.slug, "images": [
                    SimpleUploadedFile("portrait.jpg", image_bytes, "image/jpeg"),
                    SimpleUploadedFile("portrait-two.jpg", second_buffer.getvalue(), "image/jpeg"),
                ]},
                format="multipart",
            )
            self.assertEqual(uploaded.status_code, 201)
            self.assertEqual(len(uploaded.data), 2)
            photo = GalleryPhoto.objects.order_by("id").first()
            self.assertTrue(photo.image.storage.exists(photo.image.name))

            public_list = self.client.get("/api/gallery/photos/?category=portraits")
            self.assertEqual(public_list.status_code, 200)
            self.assertEqual(len(public_list.data), 2)
            self.assertEqual(public_list.data[0]["category"], "portraits")
            self.assertIn("/media/gallery/", public_list.data[0]["image_url"])

            updated = self.client.patch(
                f"/api/admin/gallery/photos/{photo.pk}/",
                {"category": "fashion", "title": "Studio editorial"},
                format="json",
            )
            self.assertEqual(updated.status_code, 200)
            photo.refresh_from_db()
            self.assertEqual(photo.category.slug, "fashion")
            self.assertEqual(photo.title, "Studio editorial")

            old_image_name = photo.image.name
            replacement_buffer = BytesIO()
            Image.new("RGB", (20, 20), color=(140, 90, 180)).save(replacement_buffer, format="PNG")
            replaced = self.client.patch(
                f"/api/admin/gallery/photos/{photo.pk}/",
                {"image": SimpleUploadedFile("replacement.png", replacement_buffer.getvalue(), "image/png")},
                format="multipart",
            )
            self.assertEqual(replaced.status_code, 200)
            photo.refresh_from_db()
            self.assertNotEqual(photo.image.name, old_image_name)
            self.assertFalse(photo.image.storage.exists(old_image_name))

            category_delete = self.client.delete("/api/admin/gallery/categories/portraits/")
            self.assertEqual(category_delete.status_code, 400)
            self.assertTrue(GalleryCategory.objects.filter(slug="portraits").exists())

            removed = self.client.delete(f"/api/admin/gallery/photos/{photo.pk}/")
            self.assertEqual(removed.status_code, 204)
            self.assertEqual(GalleryPhoto.objects.count(), 1)
            self.assertFalse(photo.image.storage.exists(photo.image.name))
