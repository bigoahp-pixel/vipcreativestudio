from django.contrib import admin

from .models import Booking
from .notifications import send_status_update


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("reference", "full_name", "service", "appointment_date", "status", "owner_email_status", "whatsapp_status")
    list_filter = ("status", "service", "appointment_date")
    search_fields = ("reference", "full_name", "email", "phone")
    readonly_fields = ("reference", "idempotency_key", "created_at", "updated_at")

    def has_add_permission(self, request):
        return False

    def save_model(self, request, obj, form, change):
        previous = Booking.objects.get(pk=obj.pk) if change else None
        super().save_model(request, obj, form, change)
        if previous:
            rescheduled = (
                previous.appointment_date != obj.appointment_date
                or previous.appointment_time != obj.appointment_time
            )
            if previous.status != obj.status or rescheduled:
                send_status_update(obj, rescheduled=rescheduled)
