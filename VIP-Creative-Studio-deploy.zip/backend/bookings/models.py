import uuid

from django.db import models


class Booking(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        CONFIRMED = "confirmed", "Confirmed"
        COMPLETED = "completed", "Completed"
        CANCELLED = "cancelled", "Cancelled"

    class ContactMethod(models.TextChoices):
        WHATSAPP = "whatsapp", "WhatsApp"
        PHONE = "phone", "Telephone"
        EMAIL = "email", "Email"

    reference = models.CharField(max_length=24, unique=True, editable=False)
    idempotency_key = models.UUIDField(unique=True, default=uuid.uuid4, editable=False)
    request_fingerprint = models.CharField(max_length=64, editable=False)
    full_name = models.CharField(max_length=120)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    service = models.CharField(max_length=50)
    appointment_date = models.DateField()
    appointment_time = models.TimeField()
    location = models.CharField(max_length=240, blank=True)
    budget = models.CharField(max_length=100, blank=True)
    people_count = models.PositiveSmallIntegerField(null=True, blank=True)
    requirements = models.TextField(blank=True)
    preferred_contact = models.CharField(max_length=12, choices=ContactMethod.choices)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING)
    internal_notes = models.TextField(blank=True)
    owner_email_status = models.CharField(max_length=20, default="pending")
    client_email_status = models.CharField(max_length=20, default="pending")
    whatsapp_status = models.CharField(max_length=30, default="not_configured")
    whatsapp_message_id = models.CharField(max_length=120, blank=True)
    status_email_status = models.CharField(max_length=20, default="not_attempted")
    status_whatsapp_status = models.CharField(max_length=30, default="not_attempted")
    status_whatsapp_message_id = models.CharField(max_length=120, blank=True)
    status_notification_rescheduled = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        if not self.reference:
            self.reference = f"VIP-{uuid.uuid4().hex[:16].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.reference} — {self.full_name}"


class GalleryCategory(models.Model):
    slug = models.SlugField(max_length=64, unique=True)
    title = models.CharField(max_length=80)
    service = models.CharField(max_length=50, blank=True)

    class Meta:
        ordering = ["id"]
        verbose_name_plural = "gallery categories"

    def __str__(self):
        return self.title


class GalleryPhoto(models.Model):
    category = models.ForeignKey(GalleryCategory, on_delete=models.CASCADE, related_name="photos")
    image = models.ImageField(upload_to="gallery/%Y/%m/")
    title = models.CharField(max_length=120)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return f"{self.title} — {self.category.title}"
