# V.I.P Creative Studio

A responsive photography studio website and booking platform. The React/Vite site submits bookings to a Django REST API. Bookings are stored in the database before email or WhatsApp notifications are attempted. Every request starts as **Pending** and must be confirmed by studio staff.

## Project structure

- `frontend/` — React, Vite, premium portfolio site, booking form, and private staff dashboard.
- `backend/` — Django REST API, database models, email and WhatsApp notifications, and staff administration.
- `.env.example` — configuration template. Copy it to `.env` and replace the placeholders; never commit `.env`.

## Local setup (Windows PowerShell)

1. Install Python 3.10+ and Node.js 20+.
2. Create a virtual environment and install backend dependencies:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r backend\requirements.txt
   ```

3. Copy `.env.example` to `.env` and set email credentials. For local development, the backend uses SQLite unless `DATABASE_URL` is set.
4. In a PowerShell window, start the API:

   ```powershell
   cd backend
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py runserver
   ```

5. In another window, start the frontend:

   ```powershell
   cd frontend
   Copy-Item .env.example .env
   npm install
   npm run dev
   ```

6. Visit `http://localhost:5173`. The staff dashboard is at `http://localhost:5173/admin`. Sign in using a Django staff/superuser account. A superuser can edit public gallery category names and linked booking services, add categories, and create staff accounts. Staff can view and manage bookings; only superusers can create staff accounts.

For a local email-only smoke test, set `EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend` in `.env`. Production email errors are recorded against the booking and can be retried from the staff dashboard.

## Booking and notification behavior

- `POST /api/bookings/` validates the request, rejects past dates and invalid international phone numbers, normalizes valid global phone formats (including `+` and `00` country-code prefixes) to E.164, and persists it with a unique reference and idempotency key.
- `GET /api/gallery/categories/` returns the persistent categories used by the public portfolio. Staff can edit categories at `/api/admin/gallery/categories/`; category labels and service links update on the public site.
- The staff dashboard uploads, edits, replaces, and removes public gallery photos at `/api/admin/gallery/photos/`. Upload JPEG, PNG, or WebP files (up to 20 images per batch, 10 MB each); photos are stored under `backend/media/gallery/` and automatically appear in the selected category. Staff can edit category names and linked services and delete empty categories from the gallery manager.
- `/api/admin/staff/` is restricted to superusers and supports listing and creating staff accounts. Staff accounts can manage bookings but cannot manage other accounts.
- Email to `STUDIO_EMAIL` and the client acknowledgement are attempted after the record is saved. Delivery/configuration status is returned to the client and visible to staff. Failed or unconfigured messages can be retried after credentials are fixed.
- When staff approves, declines, completes, or reschedules a request, the client is emailed and the result is saved separately as `status_email_status`. The dashboard also has explicit **Approve appointment** and **Decline request** actions, a **Retry decision notice** action, and a manual WhatsApp message link. An email status of `sent` means the configured email backend accepted the send attempt, not proof that it reached the recipient's inbox.
- Automatic WhatsApp decision/reschedule notices are attempted only when the client actively selected WhatsApp (the form explains that this authorizes WhatsApp booking updates) and the official Cloud API credentials plus `WHATSAPP_STATUS_TEMPLATE_NAME` are configured. The approved status template must accept five body parameters in this order: booking reference, client name, update text, service, appointment date/time. `accepted` means Meta accepted the message for processing; it is not a delivery confirmation. Signed webhook callbacks update the status to `sent`, `delivered`, `read`, or `failed` when reported by Meta. Phone/SMS messages are not sent; when automatic channels are unavailable, staff can use the prepared WhatsApp update link.
- With no WhatsApp Cloud API credentials, the response includes a prefilled `https://wa.me/211922865522` enquiry link. The page opens it after a successful save when the browser permits; the client still needs to review and send the message.
- For optional Cloud API delivery, configure all of `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN`, and `WHATSAPP_TEMPLATE_NAME`. The approved template must use five body parameters in this order: booking reference, client name, service, appointment date/time, client phone. An API acceptance is shown as **accepted**, not delivered. Configure the Meta webhook URL as `/api/whatsapp/webhook/verify/` and callback as `/api/whatsapp/webhook/`, and set both webhook secrets. Signed delivery callbacks update the booking's WhatsApp status.
- Email and WhatsApp credentials are backend-only. Do not prefix secrets with `VITE_`.

## Production deployment

The following is one deployment path using Render for Django/PostgreSQL and Vercel for React. Use your own studio domain so the frontend and API can be hosted on the same site (for example, `www.your-domain.com` and `api.your-domain.com`); this avoids browser third-party-cookie problems for the session-authenticated admin.

1. **Prepare the public services and domain.** Create a managed PostgreSQL database and a Django web service on Render. Create a Vercel project from this repository with the project root set to `frontend/`. Add the DNS records/custom domains so the frontend and API are subdomains of the same registrable domain.
2. **Configure the Django service.** Use `backend/` as the service root, install with `pip install -r requirements.txt`, and run with `gunicorn config.wsgi:application`. Set the release/pre-deploy command to `python manage.py migrate && python manage.py collectstatic --noinput` so database changes and Django admin static assets are ready before the web service starts. Configure these backend environment variables in the hosting dashboard:
   - `DATABASE_URL` — the managed PostgreSQL connection URL.
   - `DJANGO_SECRET_KEY` — a newly generated, private random value; never reuse the development key or commit it.
   - `DJANGO_DEBUG=false`, `DJANGO_ALLOWED_HOSTS=api.your-domain.com`.
   - `CORS_ALLOWED_ORIGINS=https://www.your-domain.com` and `CSRF_TRUSTED_ORIGINS=https://www.your-domain.com,https://api.your-domain.com`.
   - `PUBLIC_ADMIN_URL=https://www.your-domain.com/admin`.
3. **Set up persistent gallery-media storage before enabling photo uploads.** The application saves gallery images to `MEDIA_ROOT` and does not serve uploaded media in production by default. Configure durable object storage and a Django storage backend/CDN for `MEDIA_URL`, or configure the backend host's persistent volume and web server to serve `/media/` safely. Do not rely on an ephemeral container filesystem; without production media storage and a public media URL, newly uploaded gallery images will not persist or display reliably.
4. **Configure email.** Add `STUDIO_EMAIL`, `DEFAULT_FROM_EMAIL`, `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_HOST_USER`, `EMAIL_HOST_PASSWORD`, and `EMAIL_USE_TLS` to the backend service. Use the email provider's SMTP credentials, not a personal mailbox password. Email delivery is not active until these values are set and tested.
5. **Deploy the frontend.** In Vercel set the root to `frontend/`, build command to `npm run build`, output directory to `dist`, and environment variable `VITE_API_URL=https://api.your-domain.com/api`. Deploy, then confirm the Vercel rewrite serves `/admin` and the Vercel origin matches the backend CORS/CSRF settings.
6. **Create the production administrator.** In the Render service shell, run `python manage.py createsuperuser` from the backend service. Create a new, unique strong password; do not use the local development credentials. Sign in at `https://www.your-domain.com/admin`.
7. **Test before launch.** Submit a test booking and verify its database record, status (Pending), both email deliveries, and manual WhatsApp link. Test admin login, CSRF-protected booking management, category changes, and public image URLs after configuring production media storage. Back up PostgreSQL and test restore procedures.
8. **Optional automatic WhatsApp.** Create and approve both the owner booking-alert template and a client status-update template in Meta Business Manager. The client template must use the five parameters documented above. Set `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_TEMPLATE_NAME`, `WHATSAPP_STATUS_TEMPLATE_NAME`, their language codes, and webhook secrets as backend-only environment variables. Configure the Meta webhook callback and verify both delivered and failed status callbacks. Otherwise keep Cloud API settings blank and use the manual WhatsApp flow.

## Tests

From `backend/`, run:

```powershell
python manage.py test bookings
```

The tests cover saved bookings, owner/client email attempts, WhatsApp summary links, idempotent duplicate submissions, past-date and phone validation, missing-email configuration, staff-only access, gallery category and photo management, approval/decline emails, WhatsApp status templates and delivery callbacks, notification retries, and rescheduling.

Build the frontend with:

```powershell
cd frontend
npm run build
```
